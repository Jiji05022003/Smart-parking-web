<?php

$host = 'localhost';
$db = 'parking_system'; // Change to your database name
$user = 'root'; // Change to your database username
$pass = ''; // Change to your database password

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Could not connect to the database: " . $e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Parking</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        .navbar {
            margin-bottom: 10px;
            background-color: #F7DC6F;
            font-size: 21px;
        }
        .hero {
            background-image: url('parking.jpg');
            background-size: cover;
            background-position: center;
            height: 400px;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .feature {
            text-align: center;
            padding: 20px;
            background-color: #F2C464;
        }
        .content-section {
            padding: 40px;
            background-color: #F9F9F9;
            margin-bottom: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <a class="navbar-brand" href="#">
            <img src="./images/sparks_logo.jfif" width="190" height="80" alt="ParkingPro" class="d-inline-block align-top">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                    <a class="nav-link" href="#Home">Home</a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="#Download">Download</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#Features">Features</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#Pricing">Pricing</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#Contact">Contact</a>
                </li>
            </ul>
        </div>
    </nav>

    <div id="Home" class="hero" style="background-image: url('./images/raban-haaijk-wftNpcjCHT4-unsplash (1).jpg'); background-size: cover; background-position: center top 58%; margin: 0;">
        <h1>Smart Parking</h1>
        <p>Park right around the corner.</p>
    </div>

    <div class="container d-flex flex-wrap justify-content-center mt-5">
        <div id="guide" class="content-section">
            <h2 style="font-weight: 700; font-size: 24px; line-height: 0.8; color: #333; margin-bottom: 20px;">How to Use Our Smart Parking System</h2>
            <p style="font-size: 16px; line-height: 0.8; color: #666; margin-bottom: 30px;">Welcome to our comprehensive guide on using the Smart Parking system. In this guide, you'll learn how to make the most of our innovative parking solutions.</p>

            <div style="margin-bottom: 20px;">
                <i class="fas fa-download" style="margin-right: 10px; "></i>
                <h3 style="font-weight: 700; font-size: 18px; line-height: 1.1; color: #333; margin-bottom: 5px;">Step 1: Download the App</h3>
                <p style="font-size: 16px; line-height: 1.1; color: #666;">Start by downloading our app from the App Store or Google Play Store. The app provides easy access to all our services and features.</p>
            </div>

            <div style="margin-bottom: 20px;">
                <i class="fas fa-user" style="margin-right: 10px;"></i>
                <h3 style="font-weight: 700; font-size: 18px; line-height: 1.1; color: #333; margin-bottom: 5px;">Step 2: Register and Set Up Your Account</h3>
                <p style="font-size: 16px; line-height: 1.1; color: #666;">Create an account by entering your personal details and vehicle information. This ensures a seamless parking experience.</p>
            </div>

            <div style="margin-bottom: 20px;">
                <i class="fas fa-calendar-check" style="margin-right: 10px;"></i>
                <h3 style="font-weight: 700; font-size: 18px; line-height: 1.1; color: #333; margin-bottom: 5px;">Step 3: Make a Reservation</h3>
                <p style="font-size: 16px; line-height: 1.1; color: #666;">Reserve your parking spot in advance to guarantee availability. Choose from various pricing options that suit your needs.</p>
            </div>

            <div>
                <i class="fas fa-car" style="margin-right: 10px;"></i>
                <h3 style="font-weight: 700; font-size: 18px; line-height: 1.1; color: #333; margin-bottom: 5px;">Step 4: Scan QR Code upon arriving at the Parking Spot </h3>
                <p style="font-size: 16px; line-height: 1.1; color: #666;">Arrive at your designated parking spot and enjoy a hassle-free parking experience with our cutting-edge technology.</p>
            </div>
        </div>
    </div>


    <div id="Features" class="container mt-5">
        <div class="row">
            <div class="col-md-4 feature">
                <h3>Secure Parking</h3>
                <p>24/7 surveillance and secure access to ensure your vehicle is safe.</p>
            </div>
            <div class="col-md-4 feature">
                <h3>Convenient System</h3>
                <p>Improved parking experience in convenience of your device with QR code technology.</p>
            </div>
            <div class="col-md-4 feature">
                <h3>Affordable Rates</h3>
                <p>Competitive pricing to suit your budget.</p>
                <p><a href="pricing.php" class="btn btn-warning">See Pricing</a></p>
            </div>
        </div>
    </div>
    <div style="padding: 50px;" class="d-flex justify-content-space-evenly mt-5 pt-3 bg-dark" >

        <div style="background-color: white; width: 60px; height: 200px; margin: 0 20px; border-radius: 10px; box-shadow: 0 4px 8px gray;" class="bg-light p-3 text-white flex-grow-1">
            <img src="./images/motorcycle.png" width="100%" height="100%" class="d-block" alt="Motorcycle">
        </div>
        <div style="width: 60px; height: 200px; margin: 0 20px; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);" class="bg-light p-3 flex-grow-1">
            <img src="./images/459492050_436672765581287_8142416424827305066_n.png" width="100%" height="100%" class="d-block" alt="Car">
        </div>
        <div style="width: 60px; height: 200px; margin: 0 20px; border-radius: 10px; box-shadow: 0 4px 8px gray;" class="bg-dark p-3 text-white flex-grow-1">
            <img src="./images/truck.jpg" width="100%" height="100%" class="d-block" alt="Truck">
        </div>
    </div>

    <div id="Pricing" class="container mt-5">
        <h2 class="text-center">Pricing</h2>

        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h3 class="card-title">MOTORCYCLE RATE</h3>
                    </div>
                    <div class="card-body">
                    <?php
                                    $query = "SELECT sale_price FROM products WHERE name = ?";
                                    $statement = $conn->prepare($query);
                                    $statement->execute(['motorcycle']);

                                    $statement->setFetchMode(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                                    $result = $statement->fetchAll();
                                    if($result > 0)
                                    {
                                        foreach($result as $row)
                                        {
                                            ?>

                                            <h2><?= $row->sale_price; ?></h2>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="5">No Record Found</td>
                                        </tr>
                                        <?php
                                    }
                                ?>
                        
                                        <h2 class="card-title"></h2>
                        
                        <p class="card-text">24/7 surveillance and secure access</p>
                        <p class="card-text">Free cancellation</p>
                        <p class="card-text">No additional fees</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-success text-white">
                        <h3 class="card-title">CAR RATE</h3>
                    </div>
                    <div class="card-body">

                        <?php
                                    $query = "SELECT sale_price FROM products WHERE name = ?";
                                    $statement = $conn->prepare($query);
                                    $statement->execute(['car']);

                                    $statement->setFetchMode(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                                    $result = $statement->fetchAll();
                                    if($result > 0)
                                    {
                                        foreach($result as $row)
                                        {
                                            ?>

                                            <h2><?= $row->sale_price; ?></h2>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="5">No Record Found</td>
                                        </tr>
                                        <?php
                                    }
                                ?>
                        <p class="card-text">All basic features</p>
                        <p class="card-text">Priority parking</p>
                        <p class="card-text">Free additional driver</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header bg-warning text-white">
                        <h3 class="card-title">TRUCK RATE</h3>
                    </div>
                    <div class="card-body">
                    <?php
                                    $query = "SELECT sale_price FROM products WHERE name = ?";
                                    $statement = $conn->prepare($query);
                                    $statement->execute(['truck']);

                                    $statement->setFetchMode(PDO::FETCH_OBJ); //PDO::FETCH_ASSOC
                                    $result = $statement->fetchAll();
                                    if($result > 0)
                                    {
                                        foreach($result as $row)
                                        {
                                            ?>

                                            <h2><?= $row->sale_price; ?></h2>
                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="5">No Record Found</td>
                                        </tr>
                                        <?php
                                    }
                                ?>
                        <p class="card-text">All premium features</p>
                        <p class="card-text">Free car wash</p>
                        <p class="card-text">Free valet service</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<div id="Download" class="container mt-5">
    <h2 class="text-center">Download Our App</h2>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-dark text-white text-center">
                    <h3 class="card-title">Get Our App Today!</h3>
                </div>
                <div class="card-body d-flex flex-wrap justify-content-center align-items-center">
                    <div style="background-color: #F7DC6F;" class="m-2"><img src="./images/36121.png" width="100" height="100" alt="App Image"></div>
                    <div style="background-color: #F2C464;" class="m-2"><img src="./images/android-logo-png-transparent-images-and-icons-9.png" width="100" height="100" alt="App Image"></div>
                    <div style="background-color: #E5D8B6;" class="m-2"><img src="./images/file (4).png" width="100" height="100" alt="App Image"></div>
                    <div style="background-color: #D2B48C;" class="m-2"><img src="./images/8e3b3ea1-d2a5-4a50-90c6-9038a0e249c4.jfif" width="100" height="100" alt="App Image"></div>
                    <p class="card-text text-center">Experience convenience at your fingertips. Download our app and enjoy seamless parking solutions with just a tap!</p>
                    <a href="#" class="btn btn-success btn-lg">Download for Android</a>
                </div>
            </div>
        </div>
    </div>
</div>

    <div id="Contact" class="container mt-5">
        <h2 class="text-center">Contact</h2>

        <div class="row">
            <div class="col-md-6">
                <h3 class="text-center">Address</h3>
                <p>123 Main Street, Anytown, Philippines</p>
            </div>
            <div class="col-md-6">
                <h3 class="text-center">Phone</h3>
                <p>+63 09123456789</p>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6">
                <h3 class="text-center">Email</h3>
                <p><a href="mailto:info@parkingpro.com">info@smartparking.com</a></p>
            </div>
            <div class="col-md-6">
                <h3 class="text-center">Hours</h3>
                <p>Monday - Friday: 8am - 10pm</p>
                <p>Saturday - Sunday: 9am - 11pm</p>
            </div>
        </div>
    </div>



    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2024 Smart Parking. All Rights Reserved.</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

    <footer>
        <p>&copy; Smart Parking </p>
    </footer>
</body>
</html>

